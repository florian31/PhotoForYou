<?php
require('./include/mysql.inc.php');
require('./include/config.inc.php');
include('./include/entete.php');
?>

    <div id="body">
		<div id="content">
			
                </div>
        
    <?php
    
    include('./include/cotedroit.php');
    include('./include/pieddepage.php');
    ?>
</div>
</body>
</html>